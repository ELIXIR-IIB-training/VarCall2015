#!/bin/bash
ls -l
cd ../
ls -l
